(function () {
    $(window).scroll(function () {
        var oVal;
        oVal = $(window).scrollTop() / 500;
        return $('.blur').css('opacity', oVal);
    });
}.call(this));
